﻿//#define MySQL 
#define POSTGRES
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;


namespace ConsoleApp1
{
    internal class Program
    {
        public class saleDetailDTO
        {
            /*

                SELECT e.employeeNumber , firstname, lastname,customerNumber , customerName ,salesRepEmployeeNumber 
                                       FROM customers as c 
                                       RIGHT JOIN employees as e ON salesRepEmployeeNumber = employeeNumber 
                                       WHERE customerNumber is not NULL 
                                       ORDER BY employeeNumber
             */

            public int employeeNumber { get; set; }
            public string lastName { get; set; }
            public string firstName { get; set; }
            public int customerNumber { get; set; }
            public string customerName { get; set; }
            public string salesRepEmployeeNumber { get; set; }
        }

        static void ExecuteReaderQueryCustomerSaleList(int employeeNumber)
        {
            List<saleDetailDTO> saleList = new List<saleDetailDTO>();
            try
            {
#if POSTGRES
                string connectionString =
                        "Driver={PostgreSQL Unicode};" +
                        "Server=localhost;" +
                        "Port=5432;" +
                        "SSLmode=disable;" +
                        "Database=postgres;" +
                        "Uid=serviceapi;" +
                        "Pwd=serviceapi;";
#endif
#if MySQL
                string connectionString =
                    "Driver={MySQL ODBC 8.0 Unicode Driver};" +
                    "Server=localhost;" +
                    "Port=3309;" +
                    "SSLmode=disable;" +
                    "Database=classicmodels;" +
                    "Uid=user1;" +
                    "Pwd=user1;";
#endif
                OdbcConnection db = new OdbcConnection(connectionString);

                db.Open();

                string query = @"
                    SELECT
                        employeeNumber,
                        firstName,
                        lastName,
                        customerNumber,
                        customerName,
                        salesRepEmployeeNumber 
                    FROM classicmodels.customers AS c
                    RIGHT JOIN classicmodels.employees AS e
                        ON salesRepEmployeeNumber = ?
                    WHERE customerNumber IS NOT NULL
                    ORDER BY employeeNumber;
                ";

                OdbcCommand cmd =new OdbcCommand(query, db);
                OdbcParameter p1 = new OdbcParameter("employeeNumber", OdbcType.Text);
                p1.Value = employeeNumber;
                cmd.Parameters.Add(p1);
                OdbcDataReader reader =cmd.ExecuteReader();

                while (reader.Read())
                {
                    saleDetailDTO et = new saleDetailDTO()
                    {
                        employeeNumber =
                            Convert.ToInt32(
                                reader["employeeNumber"]),

                        firstName =
                            reader["firstName"].ToString(),

                        lastName =
                            reader["lastName"].ToString(),

                        customerNumber =
                            Convert.ToInt32(
                                reader["customerNumber"]),

                        customerName =
                            reader["customerName"].ToString(),

                        salesRepEmployeeNumber 
                            = reader["salesRepEmployeeNumber"].ToString()
                    };

                    saleList.Add(et);
                }
                db.Close();

                Console.WriteLine(
                    "employeeNumber\tfirstName\tlastName\t\tcustomerNumber\t\tcustomerName\t\tsalesRepEmployeeNumber");

                foreach (saleDetailDTO e in saleList)
                {
                    Console.WriteLine(
                        $"{e.employeeNumber}\t\t" +
                        $"{e.firstName}\t\t" +
                        $"{e.lastName}\t\t" +
                        $"{e.customerNumber}\t\t\t" +
                        $"{e.customerName}\t\t"+
                        $"{e.salesRepEmployeeNumber}");
                }

                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            
        }



        // ============================================================
        // s01-18 : PostgreSQL Function
        // ============================================================
        static void ExecuteScalarCountCustomerByEmployeenumber(int employeeNumber)
        {
            try
            {
                string connectionString =
                        "Driver={PostgreSQL Unicode};" +
                        "Server=localhost;" +
                        "Port=5432;" +
                        "SSLmode=disable;" +
                        "Database=postgres;" +
                        "Uid=serviceapi;" +
                        "Pwd=serviceapi;"+
                        "Pqopt={options=-csearch_path=classicmodels};";
                OdbcConnection db = new OdbcConnection(connectionString);

                db.Open();
                /*
                        SELECT count(customers.customerNumber) 
						FROM customers  
						RIGHT JOIN employees ON customers.salesRepEmployeeNumber = 1165
						WHERE customers.customerNumber is not NULL 
                 */
                string query = @"
	                       SELECT count(customers.customerNumber) 
						   FROM customers  
						   RIGHT JOIN employees ON customers.salesRepEmployeeNumber = ?
						   WHERE customers.customerNumber is not NULL 
                    ";
                
                OdbcCommand cmd = new OdbcCommand(query, db);

                OdbcParameter p1 = new OdbcParameter("employeeNumber", OdbcType.Int);
                p1.Value = employeeNumber;
                cmd.Parameters.Add(p1);

                string customerNumber = Convert.ToString( cmd.ExecuteScalar());

                Console.WriteLine( $"number of customerNumber : {customerNumber}");

                db.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // ============================================================
        // s01-15 : update_orderdetails()        // ============================================================
        static void NonQuery_update_orderdetails(int orderNumber,decimal adjustvalue)
        {
            try
            {
                string connectionString =
                        "Driver={PostgreSQL Unicode};" +
                        "Server=localhost;" +
                        "Port=5432;" +
                        "SSLmode=disable;" +
                        "Database=postgres;" +
                        "Uid=serviceapi;" +
                        "Pwd=serviceapi;" +
                        "Pqopt={options=-csearch_path=classicmodels};";
                OdbcConnection db = new OdbcConnection(connectionString);

                db.Open();
                /*
                    UPDATE classicmodels.orderdetails
                    SET priceEach = priceEach + 0.01
                    WHERE orderNumber = '10100';
                    select priceEach from classicmodels.orderdetails where orderNumber = '10100'
                 */
                string query = @"
                    UPDATE classicmodels.orderdetails
                    SET priceEach = priceEach + ?
                    WHERE orderNumber = ?;
                ";

                OdbcCommand cmd = new OdbcCommand(query, db);
                OdbcParameter p1 = new OdbcParameter("adjustvalue", OdbcType.Double);
                p1.Value = adjustvalue;
                cmd.Parameters.Add(p1);

                OdbcParameter p2 = new OdbcParameter("orderNumber", OdbcType.Text);
                p2.Value = orderNumber;
                cmd.Parameters.Add(p2);

                int numRec = cmd.ExecuteNonQuery();

                Console.WriteLine(
                    $"update orderdetail : {numRec}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // ============================================================
        // s01-16 : transaction
        // ============================================================
        static void trans_orderdetails(int orderNumber)
        {
            try
            {
                string connectionString =
                        "Driver={PostgreSQL Unicode};" +
                        "Server=localhost;" +
                        "Port=5432;" +
                        "SSLmode=disable;" +
                        "Database=postgres;" +
                        "Uid=serviceapi;" +
                        "Pwd=serviceapi;" +
                        "Pqopt={options=-csearch_path=classicmodels};";
                OdbcConnection db = new OdbcConnection(connectionString);

                db.Open();

                OdbcTransaction sqlTrans = db.BeginTransaction();

                try
                {
                    // ------------------------------------------------
                    // UPDATE
                    // ------------------------------------------------
                    string query1 = @"
                                        UPDATE classicmodels.orderdetails
                                        SET priceEach = 99999
                                        WHERE orderNumber = 10100;
                                    ";

                    using (OdbcCommand cmd1 = new OdbcCommand(query1, db, sqlTrans))
                    {
                        int numRec1 = cmd1.ExecuteNonQuery();
                        Console.WriteLine($"update orderdetails : {numRec1}");
                    }

                    // ------------------------------------------------
                    // INSERT 1
                    // ------------------------------------------------
                    string query2 = @"
                                        INSERT INTO classicmodels.orders
                                        (
                                            orderNumber,
                                            orderDate,
                                            requiredDate,
                                            shippedDate,
                                            status,
                                            customerNumber
                                        )
                                        VALUES (?, ?, ?, ?, ?, ?);
                                    ";

                    using (OdbcCommand cmd2 = new OdbcCommand(query2, db, sqlTrans))
                    {
                        cmd2.Parameters.Add(new OdbcParameter("orderNumber", OdbcType.Int) { Value = orderNumber });
                        cmd2.Parameters.Add(new OdbcParameter("orderDate", OdbcType.Date) { Value = new DateTime(2003, 1, 6) });
                        cmd2.Parameters.Add(new OdbcParameter("requiredDate", OdbcType.Date) { Value = new DateTime(2003, 1, 13) });
                        cmd2.Parameters.Add(new OdbcParameter("shippedDate", OdbcType.Date) { Value = new DateTime(2003, 1, 10) });
                        cmd2.Parameters.Add(new OdbcParameter("status", OdbcType.VarChar) { Value = "In Process" });
                        cmd2.Parameters.Add(new OdbcParameter("customerNumber", OdbcType.Int) { Value = 103 });

                        int numRec2 = cmd2.ExecuteNonQuery();
                        Console.WriteLine($"insert into orders : {numRec2}");
                    }

                    sqlTrans.Commit();
                    Console.WriteLine("COMMIT");
                }
                catch (Exception e)
                {
                    try
                    {
                        sqlTrans.Rollback();
                        Console.WriteLine($"ROLLBACK: {e.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }


        static void Main(string[] args)
        {

            ExecuteScalarCountCustomerByEmployeenumber(1165);
            ExecuteReaderQueryCustomerSaleList(1165);
            NonQuery_update_orderdetails(10100, 0.01m);
            trans_orderdetails(99911);
            trans_orderdetails(99911);

        }
    }
}

 