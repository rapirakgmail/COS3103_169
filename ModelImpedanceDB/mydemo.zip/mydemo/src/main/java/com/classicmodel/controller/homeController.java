package com.classicmodel.controller;

import javax.swing.text.html.Option;
//import javax.websocket.server.PathParam;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/") //root
public class homeController {

	@GetMapping("/")
	 @ResponseBody
	String home()
	{
	     return "<h1> Home <h1>";
	}
		
}

