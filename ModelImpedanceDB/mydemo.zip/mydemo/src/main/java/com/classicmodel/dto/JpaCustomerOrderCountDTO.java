package com.classicmodel.dto;


public class JpaCustomerOrderCountDTO {

    private long customerId;
    private String name;
    private long orderCount;

    public JpaCustomerOrderCountDTO(
            long customerId,
            String name,
            long orderCount) {

        this.customerId = customerId;
        this.name = name;
        this.orderCount = orderCount;
    }

    public long getId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public long getOrderCount() {
        return orderCount;
    }
}