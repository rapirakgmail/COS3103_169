package com.classicmodel.services;

import org.demo.entities.*;

import com.classicmodel.dto.JdbcCustomerOrderCountDTO;
import com.classicmodel.dto.JpaCustomerOrderCountDTO;
import com.classicmodel.repositories.VCustomerOrderRepository;
import com.classicmodel.repositories.JpaCustomerOrderRepositoryImpl;
import com.classicmodel.repositories.EmployessRepository;
import com.classicmodel.repositories.JdbcCustomerOrderRepository;
import com.classicmodel.repositories.JpaCustomerRepository;
import com.classicmodel.repositories.JpaCustomerOrderRepository;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


@Service
public class CustomerService {


	@Autowired VCustomerOrderRepository mVCustomerOrderRepository;
	
	
	@Autowired
	@Qualifier("JdbcCustomerOrderRepositoryImpl")
	private JdbcCustomerOrderRepository mJdbcCustomerOrderRepository;

	@Autowired
	@Qualifier("JpaCustomerOrderRepositoryImpl")
	private JpaCustomerOrderRepository  mJpaCustomerOrderRepository;
	
		
	public List<CustomerOrderCount> getCustomerOrderCount() {
		return 	mVCustomerOrderRepository.findAll();
	}
	
	public List<JdbcCustomerOrderCountDTO> getJdbcCustomerOrder() {

	  List<JdbcCustomerOrderCountDTO> dtos =
			  mJdbcCustomerOrderRepository.getCustomerOrderCount();
	  return dtos;
	    
	}	
	
	public List<JpaCustomerOrderCountDTO> getJpaCustomerOrder() {

		  List<JpaCustomerOrderCountDTO> dtos = mJpaCustomerOrderRepository.getCustomerOrderCount();
			return dtos;
		    
		}	
	
}
