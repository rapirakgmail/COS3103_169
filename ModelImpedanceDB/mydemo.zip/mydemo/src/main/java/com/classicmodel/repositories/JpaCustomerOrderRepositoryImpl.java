package com.classicmodel.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import org.demo.entities.Customers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.classicmodel.dto.JdbcCustomerOrderCountDTO;
import com.classicmodel.dto.JpaCustomerOrderCountDTO;


	
@Repository("JpaCustomerOrderRepositoryImpl")
public  class JpaCustomerOrderRepositoryImpl implements JpaCustomerOrderRepository {

	@Autowired  JpaCustomerRepository mJpaCustomerRepository;

 public   List<JpaCustomerOrderCountDTO> getCustomerOrderCount() {

		  List<JpaCustomerOrderCountDTO> dtos = new ArrayList<>();
		  
		  List<Customers> cust = mJpaCustomerRepository.findAll();
		  
		   for (Customers c : cust) {

			   long count = c.getListOfOrders().size();
			   
		        JpaCustomerOrderCountDTO dto =
		                new JpaCustomerOrderCountDTO(
		                    c.getCustomernumber(),
		                    c.getCustomername(),
		                    count
		                );

		        dtos.add(dto);
		    }
		   
		  return dtos;

    }


}