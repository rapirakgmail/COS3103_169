package com.classicmodel.services;

import org.demo.entities.*;
import com.classicmodel.repositories.EmployessRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {

	@Autowired EmployessRepository mEmployessRepository;

	//EmployeeService(EmployessRepository mEmployessRepository) {
	//	this.mEmployessRepository = mEmployessRepository;
	//}
	// final employessRepository mEmployessRepository;
	//CustomerService(employessRepository mEmployessRepository) {
	//	this.mEmployessRepository = mEmployessRepository;
	//}

	
	public List<Employees> getAllEmployees() {
/*
		List<Employees> l = new ArrayList<>();
		  Employees e = new Employees();
		  e.setEmail("5555");
		  l.add(e);
*/		  
		  return mEmployessRepository.getAllEmployeesList();
	}

	
	public Optional<Employees> getEmployeeById(Integer id) {
		return 	mEmployessRepository.findById(id);
	}

	
}
