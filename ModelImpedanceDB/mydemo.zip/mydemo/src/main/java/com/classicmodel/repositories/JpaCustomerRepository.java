package com.classicmodel.repositories;
import org.demo.entities.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.classicmodel.dto.JpaCustomerOrderCountDTO;

import java.util.ArrayList;
import java.util.List;


@Repository
public interface JpaCustomerRepository extends JpaRepository<Customers, Integer> {
}

