package com.classicmodel.controller;

import  com.classicmodel.services.*;
import org.demo.entities.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.text.html.Option;
//import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/employee")	//root
public class employeesController {

	/*
  final EmployeeService mEmployeeService;
  employeesController(EmployeeService mEmployeeService) {
    this.mEmployeeService = mEmployeeService;
  }
  */
  @Autowired EmployeeService mEmployeeService;
	
	
  @GetMapping("/")
  @ResponseBody
  String home()
  {
     return "<h1> Employee test <h1>";
  }
  
  @GetMapping("/list")
  @ResponseBody
 List<Employees> getEmployeeList()
 {
      List<Employees> l  = mEmployeeService.getAllEmployees();
	  //List<Employees> l = new ArrayList<>();
	  //Employees e = new Employees();
	  //e.setEmail("xxxx");
	  //l.add(e);
	  return l;
	  
 }

  @GetMapping("/jpa")
 String getJpaEmployeeList()
 {
      //List<Employees> l  = mEmployeeService.getAllEmployees();
	  //List<Employees> l = new ArrayList<>();
	  //Employees e = new Employees();
	  //e.setEmail("xxxx");
	  //l.add(e);
	   return "jpaCustomerOrderList";
	  
 }
  
 

  //http://localhost:9900/employee/id/1002
  @GetMapping("/id/{id}")
  //@ResponseBody
  public ResponseEntity<Employees>  getEmployeeById(@PathVariable Integer id) {
//	  Optional<Employees> e = mEmployeeService.getEmployeeById(id); 
//      return e;
	  return mEmployeeService.getEmployeeById(id)
	            .map(ResponseEntity::ok)
	            .orElseGet(() -> ResponseEntity.notFound().build());
  }

}

