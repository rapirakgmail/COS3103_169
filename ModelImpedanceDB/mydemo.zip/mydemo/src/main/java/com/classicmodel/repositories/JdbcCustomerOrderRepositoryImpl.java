package com.classicmodel.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.classicmodel.dto.JdbcCustomerOrderCountDTO;

@Repository("JdbcCustomerOrderRepositoryImpl")
public class JdbcCustomerOrderRepositoryImpl
        implements JdbcCustomerOrderRepository {

    private final JdbcTemplate jdbcTemplate;

    public JdbcCustomerOrderRepositoryImpl(JdbcTemplate jdbcTemplate) 
    {

        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<JdbcCustomerOrderCountDTO> getCustomerOrderCount() {

        String sql = """
						SELECT c.customerNumber,
						       c.customerName,
						       COUNT(o.orderNumber) AS order_count
						FROM customers AS c
						JOIN orders AS o
						  ON c.customerNumber = o.customerNumber
						GROUP BY c.customerNumber;
        		     """;

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

        List<JdbcCustomerOrderCountDTO> result = new ArrayList<>();

        for (Map<String, Object> row : rows) {

            long customerId =
                    ((Number) row.get("customerNumber")).longValue();

            String name =
                    (String) row.get("customerName");

            long orderCount =
                    ((Number) row.get("order_count")).longValue();

            JdbcCustomerOrderCountDTO dto =
                    new JdbcCustomerOrderCountDTO(
                        customerId,
                        name,
                        orderCount
                    );

            result.add(dto);
        }

        return result;
    }
    }