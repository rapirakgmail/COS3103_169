package com.classicmodel.repositories;
import org.demo.entities.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


@Repository
public interface EmployessRepository extends JpaRepository<Employees, Integer> {
	@Query( value = "SELECT * FROM Employees", nativeQuery = true)
	List <Employees> getAllEmployeesList();
}

/*
 
 @Repository
public interface employessRepository extends JpaRepository<Employees, Integer>  {
	//SELECT * FROM classicmodels.customers;
	@Query( value = "SELECT * FROM Employees", nativeQuery = true)
	List <Employees> getAllEmployeesList();

	//select * from employees e where e.employeeNumber=1076
	@Query( value = "select * from employees e where e.employeeNumber= :employeeNumber", nativeQuery = true)
	Optional <Employees> getEmployeesById( @Param("employeeNumber") int id);
	
	//select *  from employees e where e.firstName like '%le%';
	//@Query( value = "SELECT * FROM Employees where Employees.FirstName LIKE CONCAT('%',:fname,'%')", nativeQuery = true)
	@Query( value = "SELECT * FROM Employees where Employees.FirstName LIKE %:fname%", nativeQuery = true)	
	List<Employees> findEmplyoeeByFName( @Param("fname") String fname);
	
	@Query( value = "select * from employees e where e.employeeNumber <> :employeeNumber", nativeQuery = true)
	List<Employees> getAllEmployeesExcludeMyself( @Param("employeeNumber") int id);

	@Query( value = "select max(e.employeeNumber) from employees e", nativeQuery = true)
	int getMaxEmployeeNumber();
	
}

 
*/