package com.classicmodel.repositories;

import java.util.List;

import com.classicmodel.dto.*;

public interface JdbcCustomerOrderRepository {

	  List<JdbcCustomerOrderCountDTO> getCustomerOrderCount();
}
