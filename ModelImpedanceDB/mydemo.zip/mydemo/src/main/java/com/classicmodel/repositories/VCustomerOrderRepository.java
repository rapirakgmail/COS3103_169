package com.classicmodel.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import org.demo.entities.*;

public interface VCustomerOrderRepository extends JpaRepository<CustomerOrderCount, Integer> {
/*
 CREATE OR REPLACE VIEW classicmodels.customer_order_count AS
	SELECT
	    c.customernumber,
	    c.customername,
	    COUNT(o.ordernumber) AS order_count
	FROM classicmodels.customers c
	JOIN classicmodels.orders o
	    ON c.customernumber = o.customernumber
	GROUP BY
	    c.customernumber,
	    c.customername
	ORDER BY
	    c.customernumber;
 */
}
