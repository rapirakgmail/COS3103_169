package com.classicmodel.controller;

import com.classicmodel.dto.JdbcCustomerOrderCountDTO;
import com.classicmodel.dto.JpaCustomerOrderCountDTO;
import  com.classicmodel.services.*;
import org.demo.entities.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.text.html.Option;
//import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/customer")	//root
public class customerController {

	/*
  final EmployeeService mEmployeeService;
  employeesController(EmployeeService mEmployeeService) {
    this.mEmployeeService = mEmployeeService;
  }
  */
  @Autowired CustomerService mCustomerService;
	
	
  @GetMapping("/")
  @ResponseBody
  String home()
  {
     return "<h1> customer test <h1>";
  }
  

  @GetMapping("/jpa")
  String getjpaCustomerList(Model model)
  {
	   long start = System.nanoTime();
 	   List<JpaCustomerOrderCountDTO> l= mCustomerService.getJpaCustomerOrder();
	   long end = System.nanoTime();
	   String time = "querytime  = " + ((end - start) / 1_000_000.0)+ " ms";	   
	   model.addAttribute("querytime", time);
 	   model.addAttribute("list", l);
 	   model.addAttribute("message", "getjpaCustomerList by view approach" );
 	   return "jpaCustomerOrderList";
 	  
  }

 @GetMapping("/jdbc")
 String getjdbcCustomerList(Model model)
 {
	   long start = System.nanoTime();
	   List<JdbcCustomerOrderCountDTO> l= mCustomerService.getJdbcCustomerOrder();
	   long end = System.nanoTime();
	   String time = "querytime  = " + ((end - start) / 1_000_000.0)+ " ms";	   
	   model.addAttribute("querytime", time);
	   model.addAttribute("list", l);
	   model.addAttribute("message", "getjdbcCustomerList by view approach" );
	   return "jdbcCustomerOrderList";
	  
 }
  
  @GetMapping("/vorder")
  public String getVCustomerOrderCount(Model model)
  {
 	  long start = System.nanoTime();
	   List<CustomerOrderCount> l= mCustomerService.getCustomerOrderCount();
	   long end = System.nanoTime();
	   String time = "querytime  = " + ((end - start) / 1_000_000.0)+ " ms";	   
	   model.addAttribute("querytime", time);
	   model.addAttribute("list", l);	   
	   model.addAttribute("message", "getcustomerorderlist by view approach" );
	   return "vCustomerOrderList";

  }
 


}

