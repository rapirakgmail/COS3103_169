package app;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Program {

    // ============================================================
    // DTO
    // ============================================================
    public static class SaleDetailDTO {
        public int employeeNumber;
        public String lastName;
        public String firstName;
        public int customerNumber;
        public String customerName;
        public String salesRepEmployeeNumber;
    }



    	
    	private static Connection getConnectionMySql() throws SQLException {
    	/*
		  <dependency>
		    <groupId>com.mysql</groupId>
		    <artifactId>mysql-connector-j</artifactId>
		    <version>8.4.0</version>
		</dependency>
    	*/
    		String url =
    			    "jdbc:mysql://localhost:3309/classicmodels" +
    			    "?useSSL=false" +
    			    "&serverTimezone=UTC" +
    			    "&allowPublicKeyRetrieval=true" +
    			    "&characterEncoding=UTF-8";

    			Connection conn = DriverManager.getConnection(url, "user1", "user1");
    			return conn;
    	}
    	
    private static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres?sslmode=disable",
				"serviceapi",//USER, 
				"serviceapi"//PASS
				);
        return conn;
    }

    private static Connection getConnectionWithSchema() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres?sslmode=disable",
        					"serviceapi",//USER, 
        					"serviceapi"//PASS
        					);
        try (Statement st = conn.createStatement()) {
            st.execute("SET search_path TO classicmodels");
        }
        return conn;
    }

    // ============================================================
    // ExecuteReaderQueryCustomerSaleList
    // ============================================================
    static void executeReaderQueryCustomerSaleList(int employeeNumber) {
        List<SaleDetailDTO> saleList = new ArrayList<>();

        //try (Connection db = getConnection()) 
        try (Connection db = getConnectionMySql()) 
        {

            String query =
                "SELECT employeeNumber, firstName, lastName, " +
                "       customerNumber, customerName, salesRepEmployeeNumber " +
                "FROM classicmodels.customers AS c " +
                "RIGHT JOIN classicmodels.employees AS e " +
                "    ON salesRepEmployeeNumber = ? " +
                "WHERE customerNumber IS NOT NULL " +
                "ORDER BY employeeNumber";

            try (PreparedStatement cmd = db.prepareStatement(query)) {
                cmd.setInt(1, employeeNumber);

                try (ResultSet rs = cmd.executeQuery()) {
                    while (rs.next()) {
                        SaleDetailDTO dto = new SaleDetailDTO();
                        dto.employeeNumber        = rs.getInt("employeeNumber");
                        dto.firstName             = rs.getString("firstName");
                        dto.lastName              = rs.getString("lastName");
                        dto.customerNumber        = rs.getInt("customerNumber");
                        dto.customerName          = rs.getString("customerName");
                        dto.salesRepEmployeeNumber= rs.getString("salesRepEmployeeNumber");
                        saleList.add(dto);
                    }
                }
            }

            System.out.println(
                "employeeNumber\tfirstName\tlastName\t\tcustomerNumber\t\tcustomerName\t\tsalesRepEmployeeNumber");

            for (SaleDetailDTO e : saleList) {
                System.out.println(
                    e.employeeNumber + "\t\t" +
                    e.firstName + "\t\t" +
                    e.lastName + "\t\t" +
                    e.customerNumber + "\t\t\t" +
                    e.customerName + "\t\t" +
                    e.salesRepEmployeeNumber);
            }

            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ============================================================
    // ExecuteScalarCountCustomerByEmployeenumber
    // ============================================================
    static void executeScalarCountCustomerByEmployeenumber(int employeeNumber) {
        try (Connection db = getConnectionWithSchema()) {

            String query =
                "SELECT count(customers.customerNumber) " +
                "FROM customers " +
                "RIGHT JOIN employees ON customers.salesRepEmployeeNumber = ? " +
                "WHERE customers.customerNumber IS NOT NULL";

            try (PreparedStatement cmd = db.prepareStatement(query)) {
                cmd.setInt(1, employeeNumber);

                try (ResultSet rs = cmd.executeQuery()) {
                    if (rs.next()) {
                        String customerNumber = rs.getString(1);
                        System.out.println("number of customerNumber : " + customerNumber);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ============================================================
    // NonQuery_update_orderdetails
    // ============================================================
    static void nonQueryUpdateOrderdetails(int orderNumber, double adjustValue) {
        try (Connection db = getConnectionWithSchema()) {

            String query =
                "UPDATE classicmodels.orderdetails " +
                "SET priceEach = priceEach + ? " +
                "WHERE orderNumber = ?";

            try (PreparedStatement cmd = db.prepareStatement(query)) {
                cmd.setDouble(1, adjustValue);
                //cmd.setString(2, String.valueOf(orderNumber));
                cmd.setInt(2, orderNumber);
                
                int numRec = cmd.executeUpdate();
                System.out.println("update orderdetail : " + numRec);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
	 // ============================================================
	 // s01-16 : transaction 
	 // ============================================================
	 static void trans_orderdetails( int orderNumber ) {
	     try (Connection db = getConnectionWithSchema()) {
	
	         db.setAutoCommit(false);   // เริ่ม transaction
	
	         try {
	             // ------------------------------------------------
	             // UPDATE
	             // ------------------------------------------------
	             String query1 =
	                 "UPDATE classicmodels.orderdetails " +
	                 "SET priceEach = 99999 " +
	                 "WHERE orderNumber = 10100";
	
	             try (PreparedStatement cmd1 = db.prepareStatement(query1)) {
	                 int numRec1 = cmd1.executeUpdate();
	                 System.out.println("update orderdetails : " + numRec1);
	             }
	
	             // ------------------------------------------------
	             // INSERT 1
	             // ------------------------------------------------
	             String query2 =
	                 "INSERT INTO classicmodels.orders " +
	                 "(orderNumber, orderDate, requiredDate, shippedDate, status, customerNumber) " +
	                 "VALUES (?, ?, ?, ?, ?, ?)";
	
	             try (PreparedStatement cmd2 = db.prepareStatement(query2)) {
	                 cmd2.setInt(1, orderNumber);
	                 cmd2.setDate(2, java.sql.Date.valueOf("2003-01-06"));
	                 cmd2.setDate(3, java.sql.Date.valueOf("2003-01-13"));
	                 cmd2.setDate(4, java.sql.Date.valueOf("2003-01-10"));
	                 cmd2.setString(5, "In Process");
	                 cmd2.setInt(6, 103);
	
	                 int numRec2 = cmd2.executeUpdate();
	                 System.out.println("insert into orders : " + numRec2);
	             }
		
	             db.commit();
	             System.out.println("COMMIT");
	
	         } catch (Exception e) {
	             try {
	                 db.rollback();
	                 System.out.println("ROLLBACK: " + e.getMessage());
	             } catch (SQLException ex) {
	                 ex.printStackTrace();
	             }
	         } finally {
	             try {
	                 db.setAutoCommit(true);
	             } catch (SQLException ex) {
	                 ex.printStackTrace();
	             }
	         }
	
	     } catch (Exception e) {
	         e.printStackTrace();
	     }
	 }
	 
    // ============================================================
    // Main
    // ============================================================
    public static void main(String[] args) {
        executeScalarCountCustomerByEmployeenumber(1165);
        executeReaderQueryCustomerSaleList(1165);
        nonQueryUpdateOrderdetails(10100, 0.01);
        trans_orderdetails(99910);
        trans_orderdetails(99910);
    }
}

